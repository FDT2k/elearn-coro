

module.exports = {

  nats: require('./nats'),
  mongoose: require('./mongoose'),
  logger: require('./logger'),
  errors: require('./errors'),
  plugins: {
    mongoose_entity_store: require('./plugins/mongoose-entity-store')
  }
}
