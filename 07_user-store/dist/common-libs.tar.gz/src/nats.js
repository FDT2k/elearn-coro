let Promise = require('bluebird');
const _ = require('lodash');

let nats_handler = null;

/*publish a message
subject, msg, opt_reply, opt_callback
*/
const publish = (nats,message,payload,options,callback)=>{
  nats.publish(message,payload,options,callback);
}


/*reply to a nats message if needed*/
const replyIfNeeded = (nats,replyTo,payload,options,callback)=>{
  if(!_.isNil(replyTo)){
    publish(nats,replyTo,payload,options,callback)
  }
}


/*reply to a nats message if needed*/
const reply = (nats,replyTo,payload,options,callback)=>{
    publish(nats,replyTo,payload,options,callback)
}


/*subscribe*/

const subscribe = (nats,message,callback)=>{
//  console.log(nats);
  return nats.subscribe(message,callback);

}

const unsubscribe = (nats,pid)=>{
//  console.log(nats);
  return nats.unsubscribe(pid);

}

/*expictely request one response*/
const requestOne = (nats,message,payload,callback,timeout=1000,options={})=>{
  nats.requestOne(message,payload,options,timeout,callback)
}


const request = (nats,message,payload,options,timeout,callback)=>{
  nats.request(message,payload,options,timeout,callback)
}

const requestOnePromise =(nats,message,payload,timeout=1000,options={})=>{
   return new Promise ((resolve,reject)=>{
     requestOne(nats,message,payload,(response)=>{
       if(response instanceof Error  || (!_.isNil(response.success) && response.success ===false )){
         reject(response);
       }else{
         resolve(response);
       }
     },timeout,options);
   });

}

const init_nats = ({config,logger})=>{
  return new Promise((resolve,reject)=>{
    //var nats_server = process.env.NATS_SERVERS || "localhost:4222"

    var NATS = require('nats');
    let server = '';

    if(!_.isNil(config) && !_.isNil(config.nats_server)){
      server = config.nats_server;

    }else{
      server = process.env.NATS_SERVERS || "127.0.0.1:4222"
    }
    console.log(server);
    nats_handler = NATS.connect({servers:["nats://"+server],json:true});

    let nats = {
      publish:request.bind(null,nats_handler),
      replyIfNeeded:replyIfNeeded.bind(null,nats_handler),
      reply:reply.bind(null,nats_handler),
      subscribe:subscribe.bind(null,nats_handler),
      unsubscribe:unsubscribe.bind(null,nats_handler),
      requestOne:requestOne.bind(null,nats_handler),
      requestOnePromise:requestOnePromise.bind(null,nats_handler),
      request: request.bind(null,nats_handler),
      broker_handler: nats_handler,
      logger: logger
    }
    nats_handler.on('connect',()=>{
      resolve(nats);
    });
    nats_handler.on('error',()=>{
      reject(nats);
    })

  });
}



module.exports = init_nats;
