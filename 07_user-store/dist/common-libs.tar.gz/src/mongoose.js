
let Promise = require('bluebird');
const _ = require('lodash');

module.exports = ({config,logger,mongoose})=>{
  return new Promise((resolve,reject)=>{

    if(_.isNil(mongoose)){
      mongoose = require('mongoose');
    }
    let settings = null;

    if(!_.isNil(config) && !_.isNil(config.databaseSettings)){
      settings = config.databaseSettings;
    }else{
      settings = {
        servers : process.env.MONGO_SERVER || '127.0.0.1:27017',
        db: process.env.MONGO_DATABASE || 'test',
        user: process.env.MONGO_USER || null,
        password: process.env.MONGO_PWD || null
      }
    }
  //  console.log('mongo server ' +'mongodb://'+settings.servers+'/'+settings.db);
    mongoose.connect('mongodb://'+settings.servers+'/'+settings.db,{useFindAndModify:false, useCreateIndex:true,useNewUrlParser: true, user: settings.user,
    pass: settings.pass})
//    mongoose.set('debug', true);

    var db = mongoose.connection;

    db.on('error', (error)=>{
      reject(error);
    });

    db.once('connected', (param)=>{
      resolve(param);
    });

  });
}
