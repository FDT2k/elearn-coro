
module.exports= {

  log:(message)=>{

  },

}
