const _ = require('lodash');
const AsyncLock = require('async-lock');
const lock =new AsyncLock({maxPending:10000});
const { validate, ParameterValidationError } =require ('parameter-validator');
const {InvalidPayloadError} = require('../errors');

var SerialisedError = require('serialised-error')

let subs=[];

module.exports = (nats, entity_name,plural_entity_name, MongooseModel)=>{
  const export_entity = (entity)=>{
    let res = entity.toObject();
    res.id = res._id;
    return res;
  }

  const search_entity = (payload,replyTo)=>{
    let response = {success:false}
    try {
      const {term} = validate(payload,['term']);
      MongooseModel.find(
        {
          $text:
            {
              $search: term,
              $caseSensitive: false,
              $language:'french'
            }
          },{ score: { $meta: "textScore" }
        })
      .sort({ score: { $meta: "textScore" } })
      .limit(20)
      .then((entities)=>{
        response.success = true;
        response[plural_entity_name] = entities;
        nats.replyIfNeeded(replyTo,response);
      }).catch(err=>{
        response.error = new SerialisedError(err);
        nats.replyIfNeeded(replyTo,response);
      });;
    } catch (err) {
      response.error = new SerialisedError(err);
      nats.replyIfNeeded(replyTo,response);
    }
  }

  const upsert_entity = (payload,replyTo)=>{
    let response = {success:false}
    try {
      const {filter,data} = validate(payload,['filter','data']);
      lock.acquire('key', async (done) => {
        //console.log(filter);
        MongooseModel.findOneAndUpdate(filter, { $set: data}, { new: true,upsert:true }).then((entity)=>{
          done();
          response.success=true;
          response[entity_name]=export_entity(entity);
          nats.replyIfNeeded(replyTo,response);
        }).catch(err=>{
        //  console.log(err);
          done();

          response.error = new SerialisedError(err);
          nats.replyIfNeeded(replyTo,response);
        });


      }).catch(err=>{
        response.error = new SerialisedError(err);
        nats.replyIfNeeded(replyTo,response);
      });
    } catch (err) {
      response.error = new SerialisedError(err);
      nats.replyIfNeeded(replyTo,response);
    }
  }

  const insert_entity = (payload,replyTo)=>{
    let response = {success:false}
    try {

      let food = new MongooseModel(payload);

      food.save().then((_entity)=>{
        response.success=true;
        response[entity_name]=export_entity(_entity);
        nats.replyIfNeeded(replyTo,response);
      }).catch(err=>{
        response.error = new SerialisedError(err);
        nats.replyIfNeeded(replyTo,response);
      });;
    } catch (err) {
      response.error = new SerialisedError(err);
      nats.replyIfNeeded(replyTo,response);
    }
  }

  const update_entity = (payload, replyTo)=>{
    let response = {success:false}
    try {
      const {filter,data} = validate(payload,['filter','data']);


      MongooseModel.findOneAndUpdate(filter, { $set: data}, { new: true }).then((entity)=>{

        response.success=true;
        response[entity_name]=export_entity(entity);
        nats.replyIfNeeded(replyTo,response);
      }).catch(err=>{
        response.error = new SerialisedError(err);
        nats.replyIfNeeded(replyTo,response);
      });;


    } catch (err) {
      response.error = new SerialisedError(err);
      nats.replyIfNeeded(replyTo,response);
    }
  }

  const get_entity = (payload,replyTo)=>{
    let response = {success:false}
    try {
      //const {filter,data} = validate(payload,['filter']);
      if(_.keys(payload).length ==0){
        throw new InvalidPayloadError('specify a valid payload to get a record');
      }

      let filter = payload;
      MongooseModel.findOne(filter).then((result)=>{

        response.success = true;
        response[entity_name]= export_entity(result);
        nats.replyIfNeeded(replyTo,response);

      }).catch(err=>{
        response.error = new SerialisedError(err);
        nats.replyIfNeeded(replyTo,response);
      });
    } catch (err) {
      response.error = new SerialisedError(err);
      nats.replyIfNeeded(replyTo,response);
    }
  }

  const delete_entity = (payload,replyTo)=>{
    let response = {success:false}
    try {
      //const {filter,data} = validate(payload,['filter']);
      if(_.keys(payload).length ==0){
        throw new InvalidPayloadError('specify a valid payload to remove a record');
      }

      let filter = payload;

      MongooseModel.findOneAndRemove(filter).then((entity)=>{
        response.success=true;
        response[entity_name]=export_entity(entity);
        nats.replyIfNeeded(replyTo,response);
      }).catch(err=>{
        response.error = new SerialisedError(err);
        nats.replyIfNeeded(replyTo,response);
      });;
    } catch (err) {
      response.error = new SerialisedError(err);
      nats.replyIfNeeded(replyTo,response);
    }
  }


  const list_entity = (payload,replyTo)=>{
    let response = {success:false}
    try {
      let filter = payload || {};

      MongooseModel.find(filter).then((results)=>{
        response.success = true;
        response[plural_entity_name] = _.map(results,(result)=>{
          return export_entity(result);
        });
        nats.replyIfNeeded(replyTo,response);

      }).catch(err=>{
        response.error = new SerialisedError(err);
        nats.replyIfNeeded(replyTo,response);
      });;
    } catch (err) {
      response.error = new SerialisedError(err);
      nats.replyIfNeeded(replyTo,response);
    }
  }
/*
  subs.push(nats.subscribe(`${entity_name}.search`,search_entity))
  subs.push(nats.subscribe(`${entity_name}.upsert`,upsert_entity))
  subs.push(nats.subscribe(`${entity_name}.insert`,insert_entity))
  subs.push(nats.subscribe(`${entity_name}.update`,update_entity))
  subs.push(nats.subscribe(`${entity_name}.get`,get_entity_entity))
  subs.push(nats.subscribe(`${entity_name}.delete`,delete_entity))
  subs.push(nats.subscribe(`${entity_name}.list`,list_entity))

  function exitHandler(options, exitCode) {
    _.map(subs,(sub)=>{
      nats.unsubscribe(sub);
    });
  }

  process.on('exit', exitHandler.bind(null,{cleanup:true}));
  process.on('SIGINT', exitHandler.bind(null, {exit:true}));
  process.on('SIGUSR1', exitHandler.bind(null, {exit:true}));
  process.on('SIGUSR2', exitHandler.bind(null, {exit:true}));
*/
  return {
    search_entity,upsert_entity,insert_entity,update_entity,get_entity,delete_entity,list_entity
  }

}
